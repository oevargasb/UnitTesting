﻿using System;
using NUnit.Framework;
using TestNinja.Fundamentals;

namespace TestNinja.UnitTests
{
    [TestFixture]
    public class DemeritPointsCalculatorTests
    {
        [Test]
        [TestCase(-1)]
        [TestCase(301)]
        public void CalculateDemeritPoints_SpeedIsOutOfRange_ThrowArgumentOutOfRangeException(int speed)
        {
            var calculator = new DemeritPointsCalculator();

            //wirte 2 Test Cases asserting that CalculateDemeritPoints() throws ArgumentOutOfRangeException            
            Assert.Throws<ArgumentOutOfRangeException>(() => calculator.CalculateDemeritPoints(speed));
        }
        
        [Test]
        [TestCase(65,0)]
        [TestCase(200, 27)]
        [TestCase(148, 16)]
        public void CalculateDemeritPoints_WhenCalled_ReturnDemeritPoints(int speed, int expectedResult)
        {
            var calculator = new DemeritPointsCalculator();

            var result = calculator.CalculateDemeritPoints(speed);

            //wirte 3 Test Cases asserting that CalculateDemeritPoints() is the same as expectedResult
            
            Assert.That(result, Is.EqualTo(expectedResult));
        }
    }
}