﻿using System;
using NUnit.Framework;
using TestNinja.Fundamentals;

namespace TestNinja.UnitTests
{
    [TestFixture]
    public class DemeritPointsCalculatorTests
    {
        [Test]        
        public void CalculateDemeritPoints_SpeedIsOutOfRange_ThrowArgumentOutOfRangeException(int speed)
        {
            var calculator = new DemeritPointsCalculator();

            //wirte 2 Test Cases asserting that CalculateDemeritPoints() throws ArgumentOutOfRangeException
          
        }
        
        [Test]
        public void CalculateDemeritPoints_WhenCalled_ReturnDemeritPoints(int speed, int expectedResult)
        {
            var calculator = new DemeritPointsCalculator();

            //wirte 3 Test Cases asserting that CalculateDemeritPoints() is the same as expectedResult
        }
    }
}