﻿using System.Collections;
using System.Collections.Generic;
using Moq;
using NUnit.Framework;
using TestNinja.Mocking;

namespace TestNinja.UnitTests.Mocking
{
    [TestFixture]
    public class VideoServiceTests
    {
        private VideoService _videoService;
        private Mock<IFileReader> _fileReader;
        private Mock<IVideoRepository> _repository;

        [SetUp]
        public void SetUp()
        {
            //Set up mocking for FileReader and VideoRepository objects
            
            _fileReader = new Mock<IFileReader>();
            _repository = new Mock<IVideoRepository>();
           

            //Create a new instance of VideoService class
            _videoService = new VideoService(_fileReader.Object, _repository.Object);
        }

        [Test]
        public void ReadVideoTitle_EmptyFile_ReturnError()
        {
            _fileReader.Setup(s => s.Read(It.Is<string>(v => v == "video.txt")))
                .Returns(string.Empty)
                .Verifiable();

            var result = _videoService.ReadVideoTitle();

            Assert.That(result, Is.EqualTo("Error parsing the video."));
        }

        [Test]
        public void GetUnprocessedVideosAsCsv_AllVideosAreProcessed_ReturnAnEmptyString()
        {
            _repository.Setup(s => s.GetUnprocessedVideos())
                .Returns(new List<Video>())
                .Verifiable();
            
            var result = _videoService.GetUnprocessedVideosAsCsv();

            Assert.That(result, Is.EqualTo(string.Empty));
        }

        [Test]
        public void GetUnprocessedVideosAsCsv_AFewUnprocessedVideos_ReturnAStringWithIdOfUnprocessedVideos()
        { 
            _repository.Setup(s => s.GetUnprocessedVideos())
                         .Returns(new List<Video>()
                         {
                             new Video() {Id = 2, IsProcessed = false, Title = "Skin"},
                         })
                         .Verifiable();
            
            var result = _videoService.GetUnprocessedVideosAsCsv();

            Assert.That(result, Does.Contain("2"));
        }
    }
}